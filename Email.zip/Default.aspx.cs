﻿using System;
using System.Net;
using System.Net.Mail;
using System.Web.UI;
using System.Drawing;

namespace Emailotp
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        // Send OTP
        protected void btnSendOTP_Click(object sender, EventArgs e)
        {
            try
            {
                string userEmail = txtEmail.Text.Trim();

                if (string.IsNullOrWhiteSpace(userEmail))
                {
                    lblMessage.Text = "Please enter a valid email.";
                    return;
                }

                // Generate OTP
                string otp = new Random().Next(100000, 999999).ToString();

                // Save OTP and email in Session
                Session["GeneratedOTP"] = otp;      
                Session["UserEmail"] = userEmail;

                // Create email
                MailMessage mail = new MailMessage();
                mail.To.Add(userEmail);
                mail.From = new MailAddress("narayanaswami2609@gmail.com");
                mail.Subject = "Your OTP Code";
                mail.Body = $"Your OTP is: {otp}";
                mail.IsBodyHtml = false;

                // Configure SMTP
                SmtpClient smtp = new SmtpClient
                {
                    Host = "smtp.gmail.com",
                    Port = 587,
                    EnableSsl = true,
                    Credentials = new NetworkCredential("narayanaswami2609@gmail.com", "nqmjwixkscpwchdh")
                };

                smtp.Send(mail);

                lblMessage.ForeColor = Color.Green;
                lblMessage.Text = "OTP sent successfully! Please check your email.";
            }
            catch (Exception ex)
            {
                lblMessage.ForeColor = Color.Red;
                lblMessage.Text = "Failed to send OTP: " + ex.Message;
            }
        }

        // Validate OTP
        protected void btnVerifyOTP_Click(object sender, EventArgs e)
        {
            string enteredOtp = txtOTP.Text.Trim();
            string storedOtp = Session["GeneratedOTP"] as string;

            if (string.IsNullOrEmpty(enteredOtp))
            {
                lblValidationResult.ForeColor = Color.Red;
                lblValidationResult.Text = "Please enter the OTP.";
                return;
            }

            if (enteredOtp == storedOtp)
            {
                lblValidationResult.ForeColor = Color.Green;
                lblValidationResult.Text = "OTP verified successfully!";
            }
            else
            {
                lblValidationResult.ForeColor = Color.Red;
                lblValidationResult.Text = "Invalid OTP. Please try again.";
            }
        }
    }
}
