﻿using LoginServicesAPI.Properties;
using LoginServicesAPI.TableProperties;
using MySqlDBOperations;
using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Mail;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using static System.Net.WebRequestMethods;

namespace LoginServicesAPI
{

    internal class Program
    {

        enum MainMenuOptions
        {
            Login = 1,
            Register = 2,
            Update = 3,
            Exit = 0
        }

        enum LoginMenuOptions
        {
            Loginbyotp = 1,
            LoginbyPasscode = 2,
            Exit = 0
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the Login Services API!");

            int iChoice;
            do
            {
                Console.WriteLine("\nMain Menu:");
                Console.WriteLine("1. Login");
                Console.WriteLine("2. Register");
                Console.WriteLine("3. Update User Information");
                Console.WriteLine("0. Exit");
                Console.Write("Please select an option: ");

                if (!int.TryParse(Console.ReadLine(), out iChoice))
                {
                    Console.WriteLine("Invalid input. Try again.");
                    continue;
                }

                switch (iChoice)
                {
                    case (int)MainMenuOptions.Login:
                        Login();
                        break;
                    case (int)MainMenuOptions.Register:
                        Register();
                        break;
                    case (int)MainMenuOptions.Update:
                        Update();
                        break;
                    case (int)MainMenuOptions.Exit:
                        Console.WriteLine("Exiting...");
                        break;
                    default:
                        Console.WriteLine("Invalid option, please try again.");
                        break;
                }
            } while (iChoice != 0);
        }

        public static void Login()
        {

            Helpers dbHelper = new Helpers();

            string accountSid = Resources.AccSID;
            string authToken = Resources.AuthToken;
            string fromPhone = Resources.PhoneNumber;
            string fromWhataspp = Resources.WhatsappNumber;

            Console.WriteLine("Enter Your Mobile Number (Only 10 digits): ");
            string inputNumber = Console.ReadLine();
            string dUserNumber = "+91" + inputNumber;

            bool isVerified = dbHelper.ValidateUserNumber(dUserNumber);
            if (isVerified == false)
            {
                Console.WriteLine("User not found. Please register first.");
                Register();
                return;
            }
            else if (isVerified == true)
            {
                Console.WriteLine("User found. Proceeding with verification...");
                Console.WriteLine("Select Login Method:");
                Console.WriteLine("1. Login by OTP");
                Console.WriteLine("2. Login by Passcode");
                Console.WriteLine("0. Exit");
                int loginChoice = Convert.ToInt32(Console.ReadLine());

                if (loginChoice < 0 || loginChoice > 2)
                {
                    Console.WriteLine("Invalid choice. Please try again.");
                    return;
                }
                if (loginChoice == (int)LoginMenuOptions.Exit)
                {
                    Console.WriteLine("Exiting...");
                    return;
                }
                if (loginChoice == (int)LoginMenuOptions.Loginbyotp)
                {
                    Console.WriteLine("You have selected to login using OTP.");

                    try
                    {
                        using (HttpClient client = new HttpClient())
                        {
                            var authBytes = System.Text.Encoding.ASCII.GetBytes($"{accountSid}:{authToken}");
                            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(authBytes));

                            string url = $"https://api.twilio.com/2010-04-01/Accounts/{accountSid}/Messages.json";

                            // Generate and send OTP
                            OtpSession.OTP = GenerateVerificationCode();

                            var otpData = new Dictionary<string, string>
                            {
                                  { "To", dUserNumber },
                                 { "From", fromPhone },
                                 { "Body", $"Your login OTP is: {OtpSession.OTP}" }
                             };

                            var otpContent = new FormUrlEncodedContent(otpData);
                            HttpResponseMessage otpResponse = client.PostAsync(url, otpContent).Result;

                            if (otpResponse.IsSuccessStatusCode)
                            {
                                Console.WriteLine("Verification code sent successfully.");
                            }
                            else
                            {
                                Console.WriteLine($"Failed to send verification code. Status Code: {otpResponse.StatusCode}");
                                return;
                            }

                           
                            var whatsappData = new Dictionary<string, string>
                                    {
                                        { "To", $"whatsapp:{dUserNumber}" },
                                        { "From", $"whatsapp:{fromWhataspp}" },  // Your approved Twilio WhatsApp number
                                        { "Body", $"Your login OTP is: {OtpSession.OTP}" }
                                    };

                            var whatsappContent = new FormUrlEncodedContent(whatsappData);
                            HttpResponseMessage whatsappResponse = client.PostAsync(url, whatsappContent).Result;

                            if (whatsappResponse.IsSuccessStatusCode)
                                Console.WriteLine("OTP sent via WhatsApp.");
                            else
                                Console.WriteLine($"WhatsApp send failed. Status: {whatsappResponse.StatusCode}");

                            // === OTP Validation ===
                            Console.WriteLine("Please enter the OTP you received via SMS or WhatsApp:");
                            string userInputCode = Console.ReadLine();

                            if (userInputCode == OtpSession.OTP)
                                Console.WriteLine("Login successful!");
                            else
                                Console.WriteLine("Invalid OTP. Please try again.");
                        }

                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"An error occurred: {ex.Message}");
                    }
                }
                else if (loginChoice == (int)LoginMenuOptions.LoginbyPasscode)
                {
                    Console.WriteLine("You have selected to login using Passcode.");
                    Console.WriteLine("Please enter your passcode:");
                    string userInputPasscode = Console.ReadLine();
                    bool isPasscodeVerified = dbHelper.ValidateUserPasscode(dUserNumber, userInputPasscode);
                    if (isPasscodeVerified == true)
                    {
                        Console.WriteLine("Login successful!");
                    }
                    else
                    {
                        Console.WriteLine("Invalid passcode. Please try again.");
                    }
                }
            }
        }


        public static string GenerateVerificationCode()
        {
            string otp1 = new Random().Next(10000, 99999).ToString();
            string otp2 = new Random().Next(10000, 99999).ToString();
            return otp1 + otp2;
        }

        public static string GeneratePassCode()
        {
            string otp1 = new Random().Next(100000, 999999).ToString();
            return otp1;
        }

        public static void APIConnection()
        {
            string accountSid = Resources.AccSID;
            string authToken = Resources.AuthToken;
            string fromPhone = Resources.PhoneNumber;
            using (HttpClient client = new HttpClient())
            {
                var authBytes = System.Text.Encoding.ASCII.GetBytes($"{accountSid}:{authToken}");
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(authBytes));

                string url = $"https://api.twilio.com/2010-04-01/Accounts/{accountSid}/Messages.json";
            }
        }

        public static void Register()
        {

            Helpers dbHelper = new Helpers();
            Console.WriteLine("Welcome to the Registration Process!");
            Console.WriteLine("Enter Your Name: ");
            string userName = Console.ReadLine();
            Console.WriteLine("Enter Your Mobile Number (Only 10 digits): ");
            string inputNumber = Console.ReadLine();
            string userMobileNumber = "+91" + inputNumber;
            Console.WriteLine("Enter Your Email Address: ");
            string userEmail = Console.ReadLine();
            Console.WriteLine("Verify Your Email\nPress 1 to Verify now or 0 For Later");
            int verifystatus = Convert.ToInt32(Console.ReadLine());
            bool bUserVerification = dbHelper.ValidateUserNumber(userMobileNumber);
            if (bUserVerification == true)
            {
                Console.WriteLine("You Aleardy Registered login With Your Number");
                Login();
            }
            else if (bUserVerification == false)
            {
                Console.WriteLine("You are a new user. Proceeding with registration...");
            }
            else
            {
                Console.WriteLine("Invalid mobile number. Please try again.");
                return;
            }
            bool emailValidation = false;
            OtpSession.PassCode = GeneratePassCode(); // Always generate passcode

            if (verifystatus == 1)
            {
                emailValidation = true;
                Console.WriteLine("Email verification is enabled.");
                OtpSession.OTP = GenerateVerificationCode();

                MailMessage mail = new MailMessage();
                mail.To.Add(userEmail);
                mail.From = new MailAddress("narayanaswami2609@gmail.com");
                mail.Subject = "Your OTP Code";
                mail.Body = $"Your OTP is: {OtpSession.OTP}";
                mail.Body += $"\nYour Passcode is: {OtpSession.PassCode}";
                mail.IsBodyHtml = false;

                SmtpClient smtp = new SmtpClient
                {
                    Host = "smtp.gmail.com",
                    Port = 587,
                    EnableSsl = true,
                    Credentials = new NetworkCredential("narayanaswami2609@gmail.com", Resources.GmailPassKey)
                };

                smtp.Send(mail);

                Console.WriteLine("Email sent successfully. Please check your inbox for the OTP.");
                Console.WriteLine("Please enter the OTP sent to your email:");
                string userInputOtp = Console.ReadLine();

                if (userInputOtp == OtpSession.OTP)
                {
                    Console.WriteLine("Email verification successful!");
                }
                else
                {
                    Console.WriteLine("Invalid OTP. Please try again.");
                    Register();
                    return;
                }
            }
            else if (verifystatus == 0)
            {
                emailValidation = false;
                Console.WriteLine("Email verification skipped. Proceeding with registration...");
            }
            int result = dbHelper.RegisterUser(userName,userMobileNumber, userEmail, emailValidation, OtpSession.PassCode);
            if (result > 0)
            {
                Console.WriteLine("Registration successful!");
            }
            else
            {
                Console.WriteLine("Registration failed.");
            }

        }

        public static void Update()
        {
            Helpers dbHelper = new Helpers();
            Console.WriteLine("Welcome to the Update Process!");
            Console.WriteLine("Enter Your Mobile Number (Only 10 digits): ");
            string inputNumber = Console.ReadLine();
            string userMobileNumber = "+91" + inputNumber;
            bool isVerified = dbHelper.ValidateUserNumber(userMobileNumber);
            bool isEmailVerified = dbHelper.ValidateEmail(userMobileNumber);
            if (isVerified == false)
            {
                Console.WriteLine("User not found. Please register first.");
                Register();
                return;
            }
            else if (isVerified == true && isEmailVerified == true)
            {
                Console.WriteLine("User found. Proceeding with update...");
                Console.WriteLine("Enter New Name: ");
                string newName = Console.ReadLine();
                Console.WriteLine("Enter  Email Address: ");
                string newEmail = Console.ReadLine();
                int result = dbHelper.UpdateUser(userMobileNumber, newName, newEmail);
                if (result > 0)
                {
                    Console.WriteLine("Update successful!");
                }
                else
                {
                    Console.WriteLine("Update failed.");
                }
            }
        }
    }
}

