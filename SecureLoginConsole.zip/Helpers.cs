﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LoginServicesAPI.Properties;
using Microsoft.Win32;
using MySqlDBOperations;
using LoginServicesAPI.TableProperties;

namespace LoginServicesAPI
{
    internal class Helpers
    {
        Helper _SqlDBOps;
        public Helpers()
        {
            _SqlDBOps = new Helper(Resources.ConnectionString);
        }

        public int InsertUser(string userMobileNumber, string passcode)
        {
            string strQuery = $"INSERT INTO `loginapi`.`logininfo`(`MobileNumber`,`Passcode`)VALUES({userMobileNumber},{passcode});";
            try
            {
                int result = _SqlDBOps.ExecuteCRUDCommand(strQuery);
                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error inserting user: {ex.Message}");
                return -1; 
            }
        }

        public int RegisterUser(string UserName,string userMobileNumber,string Email,bool Email_Validation,string PassCode)
        {
            string strQueryLogin = $@"INSERT INTO `loginapi`.`logininfo`
                                    (`MobileNumber`,
                                    `Passcode`)
                                    VALUES
                                    ('{userMobileNumber}',
                                    '{PassCode}');";
            string strGetUserId = "SELECT LAST_INSERT_ID() AS User_Id;";
            
                int resultLogin = _SqlDBOps.ExecuteCRUDCommand(strQueryLogin);
                if (resultLogin <= 0)
                {
                    return -1; // Error inserting login info
                }
                var dtUserId = _SqlDBOps.ExecuteSelectQuery(strGetUserId);
                if (dtUserId.Rows.Count == 0)
                {
                    return -1; // Error retrieving user ID
                }
                int userId = Convert.ToInt32(dtUserId.Rows[0]["User_Id"]);
               
           
            string strUserQuery = $@"INSERT INTO `loginapi`.`user`
                                    (`User_Id`,
                                    `User_Name`,
                                    `MobileNumber`,
                                    `Email`,
                                    `Email_Validation`)
                                    VALUES
                                    ('{userId}',
                                    '{UserName}',
                                    '{userMobileNumber}',
                                    '{Email }',
                                    {Email_Validation });";
            try
            {
                int result = _SqlDBOps.ExecuteCRUDCommand(strUserQuery);
                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error inserting user: {ex.Message}");
                return -1; 
            }
        }

        public int UpdateUser(string UserMobileNumber,string UserName,string Email)
        {
            int Email_Validation = 1;
            string strQuery = $@"UPDATE `loginapi`.`user`
                                SET
                                `User_Name` = '{UserName}',
                                `Email_Validation` = {Email_Validation },
                                `Email` = '{Email}'
                                WHERE `MobileNumber` = '{UserMobileNumber}';";
            int iResult=_SqlDBOps.ExecuteCRUDCommand(strQuery);
            return iResult;
        }

        public User  GetByNumber(string Number)
        {
           
            User oUser = new User();
            string strQuery = $@"SELECT * FROM `loginapi`.`logininfo`WHERE MobileNumber = '{Number}';";
            var dtResult = _SqlDBOps.ExecuteSelectQuery(strQuery);
            for (int i = 0; i < dtResult.Rows.Count; i++)
            {
                oUser.User_Id = Convert.ToInt32(dtResult.Rows[i]["User_Id"]);
                oUser.Number = dtResult.Rows[i]["MobileNumber"].ToString();
                oUser.Passcode = dtResult.Rows[i]["Passcode"].ToString();
               
            }
            return oUser;
        }
        public bool ValidateUserNumber(string userMobileNumber)
        {
            User oUser = GetByNumber(userMobileNumber);
            if (oUser == null)
            {
                return false;
            }
            else if (oUser.Number == userMobileNumber)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool ValidateUserPasscode(string userMobileNumber, string passcode)
        {
            User oUser = GetByNumber(userMobileNumber);
            if (oUser == null)
            {
                return false;
            }
            else if (oUser.Number != userMobileNumber)
            {
                return false;
            }
            else if (string.IsNullOrEmpty(oUser.Passcode) || string.IsNullOrEmpty(passcode))
            {
                return false;
            }
            else if (oUser.Number == userMobileNumber && oUser.Passcode == passcode)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool ValidateEmail(string number)
        {
            if (string.IsNullOrEmpty(number))
            {
                return false;
            }
            try
            {
                string strQuery = $@"SELECT Email FROM `loginapi`.`user` WHERE Number = '{number}';";

                var dtResult = _SqlDBOps.ExecuteSelectQuery(strQuery);
                if (dtResult.Rows.Count > 0)
                {
                    return true; // Email exists
                }
                else
                {
                    return false; // Email does not exist
                }
            }
            catch
            {
                return false;
            }
        }
    }
}
