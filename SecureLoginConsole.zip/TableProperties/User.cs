﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoginServicesAPI.TableProperties
{
    internal class User 
    {

        public int User_Id { get; set; }
        public string Number { get; set; }

        public string Passcode { get; set; }
    }
}
