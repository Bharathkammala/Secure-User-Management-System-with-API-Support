﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoginServicesAPI
{
    public static class OtpSession
    {
        public static string OTP { get; set; }
        public static string PassCode { get; set; }
    }
}

