﻿using SmsAPITwilio.Properties;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web.Http;
using Twilio;
using Twilio.Http;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

public partial class _Default : System.Web.UI.Page
{
    protected void btnSend_Click(object sender, EventArgs e)
    {
        string toPhone = txtMobile.Text.Trim();
        string messageBody = txtMessage.Text.Trim();

        // Replace with your Twilio credentials
        string accountSid = Resources.AccSID;
        string authToken = Resources.AuthToken;
        string fromPhone = Resources.PhoneNumber;

        try
        {
            using (System.Net.Http.HttpClient client = new System.Net.Http.HttpClient())
            {
                // Set Basic Auth header
                var authBytes = System.Text.Encoding.ASCII.GetBytes($"{accountSid}:{authToken}");
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(authBytes));

                // Create POST data
                var postData = new Dictionary<string, string>
                {
                    { "To", toPhone },
                    { "From", fromPhone },
                    { "Body", messageBody }
                };

                var content = new FormUrlEncodedContent(postData);

                // Twilio API URL
                string url = $"https://api.twilio.com/2010-04-01/Accounts/{accountSid}/Messages.json";

                // POST to Twilio
                HttpResponseMessage response = client.PostAsync(url, content).Result;
             
                if (response.IsSuccessStatusCode)
                {
                    lblStatus.ForeColor = System.Drawing.Color.Green;
                    lblStatus.Text = "Message sent successfully!";
                }
                else
                {
                    lblStatus.ForeColor = System.Drawing.Color.Red;
                    lblStatus.Text = "Failed to send message: " + response.ReasonPhrase;
                    string errorDetails = response.Content.ReadAsStringAsync().Result;
                    lblStatus.Text = "Failed to send message: " + response.ReasonPhrase + "<br/>Details: " + errorDetails;
                }
                

            }
        }
        catch (Exception ex)
        {
            lblStatus.ForeColor = System.Drawing.Color.Red;
            lblStatus.Text = "Exception: " + ex.Message;

        }
    }
}




