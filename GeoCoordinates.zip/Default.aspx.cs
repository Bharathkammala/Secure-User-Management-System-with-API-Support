﻿using System;
using System.Net.Http;
using System.Runtime.Versioning;
using System.Threading.Tasks;
using GeoCoordinates.Properties;
using Newtonsoft.Json.Linq;

namespace YourNamespace
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected async void btnSearch_Click(object sender, EventArgs e)
        {
            await GetAddressAndLoadMap();
        }

        private async Task GetAddressAndLoadMap()
        {
            string address = txtCityName.Text;
            if (string.IsNullOrWhiteSpace(address))
            {
                litCoordinates.Text = "Please enter a valid address.";
                return;
            }

            string apiKey = Resources.APIkey; 
            string url = $"https://maps.googleapis.com/maps/api/geocode/json?address={Uri.EscapeDataString(address)}&key={apiKey}";

            using (HttpClient client = new HttpClient())
            {
                string response = await client.GetStringAsync(url);
                JObject json = JObject.Parse(response);

                string status = (string)json["status"];
                if (status != "OK")
                {
                    litCoordinates.Text = $"Google API Error: {status}";
                    return;
                }

                var location = json["results"]?[0]?["geometry"]?["location"];
                if (location != null)
                {
                    double lat = (double)location["lat"];
                    double lng = (double)location["lng"];

                    litCoordinates.Text = $"Latitude: {lat}<br/>Longitude: {lng}";

                    LoadMap(lat, lng, apiKey);
                }
                else
                {
                    litCoordinates.Text = "No results found for the given address.";
                }
            }
        }

        private void LoadMap(double latitude, double longitude, string apiKey)
        {
            string mapScript = $@"
                <script>
                    function initMap() {{
                        var location = {{ lat: {latitude}, lng: {longitude} }};
                        var map = new google.maps.Map(document.getElementById('map'), {{
                            zoom: 14,
                            center: location
                        }});
                        var marker = new google.maps.Marker({{
                            position: location,
                            map: map
                        }});
                    }}
                </script>
                <script async defer src='https://maps.googleapis.com/maps/api/js?key={apiKey}&callback=initMap'></script>";

            litMapScript.Text = mapScript;
        }
    }
}
